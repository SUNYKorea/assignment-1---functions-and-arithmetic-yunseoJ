def fahrenheit2celsius(fahrenheit): 
    F = fahrenheit
    C = (F - 32) * 5 / 9
    return C

xx = fahrenheit2celsius(40) 

def what_to_wear(celsius):
    a = int(celsius)
    if a < -10:
        print ("Puffy jacket")
    if  -10 < a < 0:
        print("Scarf")
    if 0 < a < 20: 
        print("Sweater")
    else:
        print("Light jacket")

what_to_wear(xx)
what_to_wear(fahrenheit2celsius(40))